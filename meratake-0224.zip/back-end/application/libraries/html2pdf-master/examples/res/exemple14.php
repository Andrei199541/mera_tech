<style type="text/css">
    .table-bordered {border-width: 0.25mm; border-style: solid; border-color: #aaaaaa;}
</style>
<page backtop="5mm" backbottom="5mm" backleft="5mm" backright="5mm">
    <table style="border-top: solid 1px green; margin: 0 0 10mm">
        <col class="table-bordered" style="width: 20mm;">
        <col class="table-bordered" style="width: 21mm;">
        <col class="table-bordered" style="width: 22mm;">
        <tr>
            <th style="border-top: solid 1px red">0 0</th>
            <th style="border-top: solid 1px red">0 1</th>
            <th style="border-top: solid 1px red">0 2</th>
        </tr>
        <tr>
            <td><div>1 0</div></td>
            <td>1 1</td>
            <td>1 2</td>
        </tr>
    </table>
    <table style="border-collapse: collapse;">
        <col class="table-bordered" style="width: 20mm;">
        <col class="table-bordered" style="width: 21mm;">
        <col class="table-bordered" style="width: 22mm;">
        <tr>
            <th style="border: solid 1px red" >0 0</th>
            <th style="border: solid 1px red">0 1</th>
            <th style="border: solid 1px red">0 2</th>
        </tr>
        <tr>
            <td><div>1 0</div></td>
            <td>1 1</td>
            <td>1 2</td>
        </tr>
    </table>
    <br />
    <font color="red">Hello</font><br />
    <br />
    Image : <img src="./res/logos.png" /><br />
    Image : <img src="./res/logo.png" /><br />
</page>