<?php

require dirname(__FILE__) . '/Base_Controller.php';

class Account extends Base_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('account_model');
    }

    public function profileImage_post() {
        $file = $_FILES;
        $userInfo = $this->getCurrentUser();
		$result = $this->account_model->uploadProfileImage($file, $userInfo->id);
		exit( $result );
    }

    public function changeAccount_post() {
        $data = $this->input->post();
        $userInfo = $this->getCurrentUser();
        $result = $this->account_model->changeAccountInfo($data, $userInfo->id);
		exit( $result );
    }
}