<?php

require dirname(__FILE__) . '/Base_Controller.php';

class Employee extends Base_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('employee_model');
    }

    public function addNewEmployee_post() {
        if (!$this->protect('admin')) {
            return;
        }
        $data = $this->input->post();
        $result = $this->employee_model->addNewEmployee($data);
        $this->set_response($result, 200);
    }

    public function getEmployeeCount_get() {
        if (!$this->protect('admin')) {
            return;
        }
        $count = $this->employee_model->getCounts();
		exit( json_encode(ceil($count / 10)) );
    }

    public function getEmployees_get() {
        if (!$this->protect('admin')) {
            return;
        }
        $limit = $this->input->get("limit");
        $result = $this->employee_model->getEmployees($limit);
        $this->set_response($result, 200);
    }

    public function deleteEmployee_delete() {
        if (!$this->protect('admin')) {
            return;
        }
        $id = explode("id=", file_get_contents('php://input'))[1];
        $result = $this->employee_model->deleteEmployee($id);
        $this->set_response($result, 200);
    }
}