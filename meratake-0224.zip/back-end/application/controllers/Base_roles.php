<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require dirname(__FILE__) . '/Base_Controller.php';

class Base_roles extends Base_Controller
{
    public $roles = [];

    function __construct()
    {
        parent::__construct();
        $this->load->model('base_role_model');
    }

    public function index_get()
    {       
        if (!$this->protect('admin')) return;
        
		$rows = $this->base_role_model->getRows();
        $this->set_response($rows, 200);
    }

    public function index_post()
    {
        if (!$this->protect('admin')) return;
        
		$data = json_decode(file_get_contents('php://input'), true);
        $result = $this->base_role_model->saveRow($data);
        $this->set_response($result, 200);
    }

    public function index_delete()
    {
        if (!$this->protect('admin')) return;
        
		$data = $this->input->get();
        $result = $this->base_role_model->deleteRowById($data['id']);
        $this->set_response($result, 200);
    }
}
