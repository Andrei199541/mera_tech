<?php

require dirname(__FILE__) . '/Base_Controller.php';

class Users extends Base_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('user_model');
    }

    public function index_get() {
        if (!$this->protect('admin')) {
            return;
        }

        $rows = $this->user_model->getRows();
        $this->set_response($rows, 200);
    }

    public function index_post() {
        if (!$this->protect('admin')) {
            return;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $result = $this->user_model->saveRow($data);
        $this->set_response($result, 200);
    }

    public function index_delete() {
        if (!$this->protect('admin')) {
            return;
        }

        $data = $this->input->get();
        $result = $this->user_model->deleteRowById($data['id']);
        $this->set_response($result, 200);
    }

    public function login_post() {
        $this->User_model->deleteExpiredTokens();

        $username = $this->post('email');
        $password = $this->post('password');

        $user = $this->User_model->login($username, $password);
        $response = [
            'status' => 'OK',
        ];

        if (empty($user)) {
            $response['status'] = 'INCORRECT_LOGIN';
            $response['message'] = 'Incorrect username or password';
            $this->set_response($response, 401);
            return;
        }

        $response['user'] = $user;
        $token = $this->User_model->setAcessToken($user->id, 0);
        $user->token = $token;

        $this->load->model('person_info_model');
        $person = $this->person_info_model->getRowById($user->person_id);
        $user->email = $person->email;
        $user->photo = $this->person_info_model->getPersonPhotoURL($user->person_id);
        $user->first_name = $person->first_name;
        $user->last_name = $person->last_name;
        $user->company = $person->company;
        $user->address = $person->address;
        $user->phone = $person->phone;
        $user->rights = $person->rights;
        $user->type = $person->type;

        $this->set_response($response, 200);
    }

    public function logout_post() {
        $this->User_model->logoutByToken($this->getAuthToken());
        $this->set_response([
            'status' => 'OK',
            'message' => 'Logged out successfully',
        ], 200);
    }
}