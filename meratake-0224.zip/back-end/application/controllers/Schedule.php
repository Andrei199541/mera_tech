<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require dirname(__FILE__) . '/Base_Controller.php';

class Schedule extends Base_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model("schedule_model");
    }

    public function getScheduleByCustomer_get() {
        $customer = $this->input->get("customer");
        $result = $this->schedule_model->getScheduleByCustomer($customer);
        $this->set_response($result, 200);
    }

    public function getScheduleByEmployee_get() {
        $employee = $this->input->get("employee");
        $result = $this->schedule_model->getScheduleByEmployee($employee);
        $this->set_response($result, 200);
    }

    public function getJson_get() {
        $date = $this->input->get("date");
        $userInfo = $this->getCurrentUser();
        $where = "";
        if ($userInfo->roles != "admin") {
            $where = $userInfo->id;
        }
        $result = $this->schedule_model->getJsonSchedule($date, $where);
        exit( json_encode($result));
    }

    public function deleteSchedule_delete() {
        if (!$this->protect('admin')) {
            return;
        }
        $id = explode("id=", file_get_contents('php://input'))[1];
        $result = $this->schedule_model->deleteSchedule($id);
        $this->set_response($result, 200);
    }

    public function changeJsonInfo_post() {
        if (!$this->protect('admin')) {
            return;
        }
        $data = $this->input->post();
        $result = $this->schedule_model->changeJsonInfo($data);
        $this->set_response($result, 200);
    }

    public function changeScheduleStatus_post() {
        if (!$this->protect('admin')) {
            return;
        }
        $key = $this->input->post("key");
        $flag = $this->input->post("flag");
        $result = $this->schedule_model->changeScheduleStatus($key, $flag);
        $this->set_response($result, 200);
    }

    public function getAllSchedules_get() {
        if (!$this->protect('admin')) {
            return;
        }
        $result = $this->schedule_model->getAllSchedules();
        $this->set_response($result, 200);
    }

    public function getSchedule_get() {
        $id = $this->input->get("id");
        $result = $this->schedule_model->getScheduleById($id);
        $this->set_response($result, 200);
    }
}
