<?php
defined('BASEPATH') or exit('No direct script access allowed');

require dirname(__FILE__) . '/Base_Controller.php';

class Person_info extends Base_Controller {
    private $model = null;
    public function __construct() {
        parent::__construct();
        $this->load->model('person_info_model');
        $this->model = $this->person_info_model;
    }

    public function index_get() {
        if (!$this->protect('admin')) { 
            return;
        }

        $division = $this->input->get('division'); // 0: all, 1: players, 2: coaches, 3: team managers, 4: referees.

        $rows = $this->model->getRows($division);

        if (sizeof($rows)) {
            foreach ($rows as $key => $value) {
                $rows[$key]['image'] = $this->model->getPersonPhotoURL($value['id']);
            }
        }
        $this->set_response($rows, 200);
    }

    public function getRowById_get()
    {
        if (!$this->protect('admin')) {
            return;
        }

        $id = $this->input->get('id');
        $row = $this->model->getRowById($id);
        $this->set_response($row, 200);
    }

    public function index_post() {
        if (!$this->protect('admin')) {
            return;
        }
        $data = json_decode(file_get_contents('php://input'), true);
        $result = $this->model->saveRow($data);
        $this->set_response($result, 200);
    }

    public function index_delete() {
        if (!$this->protect('admin')) {
            return;
        }

        $id = $this->input->get('id');

        $result = $this->model->deleteRowById($id);
        $this->set_response($result, 200);
    }

    public function getjsonfromfile_post()
    {
        if (!$this->protect('admin')) {
            return;
        }

        $mime_type = (mime_content_type($_FILES['file']['tmp_name']));

        if ($mime_type != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' && $mime_type != 'application/vnd.ms-excel') {
            exit(json_encode(array('status' => 'excel_type_error')));
        }

        try {
            $objPHPExcel = PHPExcel_IOFactory::load($_FILES['file']['tmp_name']);
        } catch (Exception $e) {
            exit(json_encode(array('status' => 'excel_type_error')));
        }

        $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);

        $sub_id = $this->input->get('sub_id');
        $page_id = $this->input->get('page_id');
        $conds = $this->conditionFields($page_id);

        $data = array();
        if (sizeof($allDataInSheet)) {
            $data['headers'] = $allDataInSheet[1];

            $tempAry = array();
            $n = 0;
            foreach ($allDataInSheet as $key => $val) {
                if ($key == 1) {
                    continue;
                }

                $is_blank = true;
                $checkFields = array();
                foreach ($conds as $cRow) {
                    if ($cRow[1] == '') {
                        continue;
                    }

                    if ($val[$cRow[0]] != '') {
                        $is_blank = false;
                    }

                    $checkFields[$cRow[1]] = $val[$cRow[0]];
                }

                if ($is_blank) {
                    continue;
                }

                $tempAry[$n] = str_replace("[<=9999999]", "", $val);
                $tempAry[$n]['id'] = $key;

                $person_row = $this->model->getPersonByCondition($checkFields);

                $tempAry[$n]['isExist'] = 0;
                $tempAry[$n]['person_id'] = '';
                $tempAry[$n]['isSubRow'] = 0;
                if (!is_null($person_row)) {
                    $tempAry[$n]['isExist'] = 1;
                    $tempAry[$n]['person_id'] = $person_row['id'];
                    $sub_row = $this->model->getSubRelationByPerson($person_row['id'], $sub_id, $page_id);
                    if (!is_null($sub_row)) {
                        $tempAry[$n]['isSubRow'] = 1;
                    }

                }
                $n++;
            }
            $data['data'] = $tempAry;
        }
        $this->set_response($data, 200);
    }
    
    public function getProfileByPersonId_get()
    {
        $person = $this->input->get('person');
        $rows = $this->model->getProfileByPersonId($person);
        $this->set_response($rows, 200);
    }

    public function getPersonInfoByEmail_get()
    {
        if (!$this->protect('admin')) {
            return;
        }

        $email = $this->input->get('email');
        $info = $this->model->getRowByEmail($email);
        $this->set_response($info, 200);
    }
}
