<?php

require dirname(__FILE__) . '/Base_Controller.php';

class Customer extends Base_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('customer_model');
    }

    public function addNewCustomer_post() {
        if (!$this->protect('admin')) {
            return;
        }
        $data = $this->input->post();
        $result = $this->customer_model->addNewCustomer($data);
        $this->set_response($result, 200);
    }

    public function getCustomerCount_get() {
        if (!$this->protect('admin')) {
            return;
        }
        $count = $this->customer_model->getCounts();
		exit( json_encode(ceil($count / 10)) );
    }

    public function getCustomers_get() {
        if (!$this->protect('admin')) {
            return;
        }
        $limit = $this->input->get("limit");
        $result = $this->customer_model->getCustomers($limit);
        $this->set_response($result, 200);
    }

    public function deleteCustomer_delete() {
        if (!$this->protect('admin')) {
            return;
        }
        $id = explode("id=", file_get_contents('php://input'))[1];
        $result = $this->customer_model->deleteCustomer($id);
        $this->set_response($result, 200);
    }
}