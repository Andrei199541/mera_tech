<?php

defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Base_Controller extends REST_Controller
{

    protected $_currentUser = null;

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('User_model');
    }

    protected function getAuthToken()
    {
        return $this->head('x-auth-token');
    }

    public function getCurrentUser()
    {
        if (is_null($this->_currentUser) && !is_null($this->getAuthToken())) {
            $this->_currentUser = $this->User_model->getUserByToken($this->getAuthToken());

            $this->load->model('person_info_model');
            $this->load->model('user_role_model');

            $person = $this->person_info_model->getRowById($this->_currentUser->person_id);
            $this->_currentUser->first_name = $person->first_name;
            $this->_currentUser->last_name = $person->last_name;
            $this->_currentUser->email = $person->email;
            $this->_currentUser->phone = $person->phone;
            $this->_currentUser->company = $person->company;
            $this->_currentUser->address = $person->address;

            $roles = $this->user_role_model->getRolesAsString();
            $this->_currentUser->roles = $roles['check_keys'];
        }
        return $this->_currentUser;
    }

    // Check if current user is owner of the project
    protected function checkProjectOwner($projectId) {
        if (!$this->protect()) {
            return false;
        }

        $this->load->model('Project_model');
        if (!$this->Project_model->checkPermission($projectId, $this->getCurrentUser()->userID, ROLE_PRESENTER)) {
            $this->set_response(['status' => 'BAD_REQUEST', 'message' => 'You are not an owner of this project'], 400);
            return false;
        }
        return true;
    }

    //send invite email
    protected function sendInviteEmail($recieverId, $role, $data = array())
    {
        $this->load->model('Project_model');
        $currentUser = $this->getCurrentUser();
        $receiver = $this->User_model->findRowById($recieverId);
        $project = $data['project'];
        switch ((int) $role) {
            case ROLE_CLIENT:
                $subject = 'You are assigned qwire client';
                $body = 'email/payor_mail.php';
                break;
            case ROLE_PRESENTER:
                $subject = 'You are assigned presenter of project ' . $project->name;
                $body = 'email/presenter_mail.php';
                break;
            case ROLE_AUTHOR:
                $subject = 'You are assigned author of project ' . $project->name;
                $body = 'email/author_mail.php';
                break;
            case ROLE_VIEWER:
                $subject = 'You are assigned viewer of project ' . $project->name;
                $body = 'email/viewer_mail.php';
                break;
            default:
        }

        $templateData = array(
            'receiver' => $receiver->nameFirst,
            'sender' => $currentUser->nameFirst . ' ' . $currentUser->nameLast,
            'project' => $project->name,
            'login' => base_frontend_url(),
        );
        if (!empty($data['presentation'])) {
            $templateData['presentation'] = $data['presentation']->name;
        }
        if (isset($data['message'])) {
            $templateData['message'] = $data['message'];
        }

        $body = $this->load->view($body, $templateData, true);

        // email settings
        return send_email([
            'to' => $receiver->emailAddress,
            'message' => $body,
            'subject' => $subject,
        ]);
    }

    public function protect($roles = null)
    {
        if (empty($this->User_model->isValidToken($this->getAuthToken()))) {
            $this->set_response(['status' => 'UNAUTHORIZED', 'message' => 'You need to login first'], 401);
            return false;
        }

        if (!$this->rc($roles)) {
            $this->set_response(['status' => 'NO_PERMISSION', 'message' => 'You need to get permission'], 401);
            return false;
        } 
        return true;
    }

    /**
     * rc is abbr of Role Check, 2019-1-20, Eric Vadim.
     */
    public function rc($roles = null, $userId = null)
    {
        if (is_null($roles) || $roles == '') {
            return false;
        }
        if (gettype($roles) == 'string') {
            $roles = explode(',', $roles);
        }
        if (!is_array($roles)) {
            $roles = [$roles];
        }

        $user = is_null($userId) ? $this->getCurrentUser() : $this->User_model->getUserById($userId);

        $userRoles = explode(',', $user->roles);
        $flag = false;
        if (sizeof($userRoles)) {
            foreach ($userRoles as $userRole) {
                if (in_array($userRole, $roles)) {
                    $flag = true;
                    break;
                }
            }
        }
        return $flag;
    }

    /**
     * mc is abbr of Team Membership Check, 2019-1-22, Eric Vadim.
     */
    public function tmc($memberships, $teamId)
    {
        if (is_null($memberships) || $memberships == '') {
            return false;
        }
        if (gettype($memberships) == 'string') {
            $memberships = explode(',', $memberships);
        }
        if (!is_array($memberships)) {
            $memberships = [$memberships];
        } 

        $this->load->model('membership_plan_item_model');
        $teamMemberships = $this->membership_plan_item_model->getMembershipItemsByTeamId($teamId);
        $teamMemberships = explode(',', $teamMemberships);

        $flag = false;
        if (sizeof($teamMemberships)) {
            foreach ($teamMemberships as $teamMembership) {
                if (in_array($teamMembership, $memberships)) {
                    $flag = true;
                    break;
                }
            }
        }
        return $flag;
    }
}
