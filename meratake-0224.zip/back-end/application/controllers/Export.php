<?php
defined('BASEPATH') or exit('No direct script access allowed');

require_once APPPATH . "/../vendor/autoload.php";
require_once APPPATH . "/libraries/PHPExcel/Classes/PHPExcel.php";
require_once APPPATH . "/libraries/PHPExcel/Classes/PHPExcel/IOFactory.php";
use Spipu\Html2Pdf\Html2Pdf;

class Export extends CI_Controller
{
    public $roles = [];
    public $path = "uploads/temp/";

    public function __construct()
    {
        parent::__construct();
        error_reporting(E_ALL);
        ini_set('display_errors', '0');
    }

    public function coachreport()
    {
        $gameId = $this->input->get('game_id');
        $token = $this->input->get('token');

        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel_IOFactory');

        $objPHPExcel = new PHPExcel();

        $myWorkSheet = new PHPExcel_Worksheet($objPHPExcel, 'My Data');
        
        // coach report data
        $coachDataSheet = $objPHPExcel->createSheet(0);
        $coachDataSheet->setCellValue('A1', 'Hello')
            ->setCellValue('B2', 'world!')
            ->setCellValue('C1', 'Hello')
            ->setCellValue('D2', 'world!');
        $coachDataSheet->setTitle("Coach Report");

        // progression data
        $progressionDataSheet = $objPHPExcel->createSheet(1);
        $progressionDataSheet->setCellValue('A1', 'Hello')
        ->setCellValue('B2', 'world!')
        ->setCellValue('C1', 'Hello')
        ->setCellValue('D2', 'world!');
        $progressionDataSheet->setTitle("Progression Report");
         
        // incident data
        $incidentDataSheet = $objPHPExcel->createSheet(2);
        $incidentDataSheet->setCellValue('A1', 'Hello')
            ->setCellValue('B2', 'world!')
            ->setCellValue('C1', 'Hello')
            ->setCellValue('D2', 'world!');
        $incidentDataSheet->setTitle("Incident Data");

        $objPHPExcel->setActiveSheetIndex(0);

        // Save it as an excel 2003 file
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

        $objWriter->save($this->path . "a.xlsx");
        exit;
    }

    private function getGameData($gameId, $token)
    {
        $this->load->model('game_schedule_model');
        $this->load->model('base_team_model');
        $this->load->model('base_league_model');
        $this->load->model('base_competition_model');
        $this->load->model('game_referee_model');
        $this->load->model('person_info_model');
        $this->load->model('person_referee_model');
        $this->load->model('game_score_model');
        $this->load->model('game_record_model');
        $this->load->model('user_model');

        $this->_currentUser = $this->user_model->getUserByToken($token);
        if ($this->_currentUser) {
            $person = $this->person_info_model->getRowById($this->_currentUser->person_id);
        } else {
            die();
        }

        $game = $this->game_schedule_model->getRowById($gameId);

        $homeTeam = $this->base_team_model->getRowById($game->home_team_id);
        if ($game->away_team_id) {
            $awayTeam = $this->base_team_model->getRowById($game->away_team_id);
        } else {
            $awayTeam = (object) ['team_name' => '', 'club_id' => '0'];
        }
        $arys = $this->base_league_model->getRowById($game->league_id);
        if (count($arys) > 0) {
            $leagueItem = $arys[0];
            $competition = $this->base_competition_model->getRowById($leagueItem->competition_id);
            $league = "";
            if (count($competition)) {
                $league .= $competition[0]->competition_name;
            }
            $seasones = array(1 => 'Spring', 2 => 'Summer', 3 => 'Winter');
            $league .= "(" . $seasones[$leagueItem->season] . "-" . substr($leagueItem->start_date, 0, 4) . ")";
        } else {
            $league = "";
        }

        $refereeRow = $this->game_referee_model->getRowByGameId($gameId);

        if ($refereeRow && $refereeRow->referee1) {
            $referee1 = $this->person_referee_model->getRefereePersonId($refereeRow->referee1);
        } else {
            $referee1 = new stdClass();
        }

        if ($refereeRow && $refereeRow->referee2) {
            $referee2 = $this->person_referee_model->getRefereePersonId($refereeRow->referee2);
        } else {
            $referee2 = new stdClass();
        }
        if ($refereeRow && $refereeRow->referee3) {
            $referee3 = $this->person_referee_model->getRefereePersonId($refereeRow->referee3);
        } else {
            $referee3 = new stdClass();
        }

        $gamescores = $this->game_score_model->getTeamScores($gameId);
        foreach ($gamescores as $row) {
            if ($game->home_team_id == $row->team_id) {
                $game->home_team_scroe = $row->goal;
            }
            if ($game->away_team_id == $row->team_id) {
                $game->away_team_score = $row->goal;
            }
        }
        if (!$game->home_team_scroe) {
            $game->home_team_scroe = 0;
        }
        if (!$game->away_team_score) {
            $game->away_team_score = 0;
        }

        $rows = $this->game_record_model->getRows($gameId, 2);

        $yellowCards = array();
        $redCards = array();
        $recordItems = array();

        $teams = array($game->home_team_id => $homeTeam->team_name, $game->away_team_id => $awayTeam->team_name);

        foreach ($rows as $row) {
            $row->team_name = $teams[$row->team_id];
            if ($row->sport_id == 1) {
                if ($row->item_id == 5) {
                    $yellowCards[] = $row;
                }
                if ($row->item_id == 6) {
                    $redCards[] = $row;
                }
            } else if ($row->sport_id == 2 && $row->kind == '2') {
                $recordItems[] = $row;
            }
        }

        $data = array(
            'game' => $game,
            'homeTeam' => $homeTeam,
            'awayTeam' => $awayTeam,
            'league' => $league,
            'referee1' => $referee1,
            'referee2' => $referee2,
            'referee3' => $referee3,
            'yellowCards' => $yellowCards,
            'redCards' => $redCards,
            'recordItems' => $recordItems,
            'person' => $person,
        );
        return $data;
    }

    public function progression()
    {
        $gameId = $this->input->get('game_id');
        $token = $this->input->get('token');
        $data = $this->getGameData($gameId, $token);
        $game = $data['game'];
        $league = $data['league'];

        $this->load->model('game_score_model');
        $this->load->model('base_game_locations_model');
        $teamEffs = $this->game_score_model->getGameTeamEff($game->home_team_id, $gameId);
        $loaction = $this->base_game_locations_model->getRowById($game->field_id);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=coach_report.csv');
        $out = fopen('php://output', 'w');
        fputcsv($out, array('Date of Game', $game->game_date));
        fputcsv($out, array('Opponent', $league));
        fputcsv($out, array('Loaction', $loaction ? $loaction->field_name : ''));
        fputcsv($out, array('Result/Score', ' ' . $game->home_team_scroe . " - " . $game->away_team_score . ' '));
        fputcsv($out, array(''));
        fputcsv($out, array('', 'Positive', 'Negative', 'Total', 'Ratio'));
        foreach ($teamEffs as $row) {
            fputcsv($out, array($row->item_name, $row->p_pts * 1, $row->n_pts * 1, $row->p_pts + $row->n_pts, number_format((($row->p_pts - $row->n_pts) / ($row->p_pts + $row->n_pts)), 5)));
        }
        fclose($out);
    }

    public function referee()
    {
        $gameId = $this->input->get('game_id');
        $token = $this->input->get('token');

        $data = $this->getGameData($gameId, $token);

        $body = $this->load->view('export/referee', $data, true);

        $html2pdf = new Html2Pdf('P', 'A4', 'en', true, 'UTF-8');
        $html2pdf->pdf->SetDisplayMode('fullpage');
        $html2pdf->writeHTML($body);
        $html2pdf->output("Referee_Report.pdf");
    }

    public function exportBasketballGame()
    {
        $gameId = $this->input->get('game_id');
        $teamId = $this->input->get('team_id');

        $this->load->model('game_record_model');
        $this->load->model('game_schedule_model');
        $this->load->model('base_record_item_model');

        $base_info = $this->game_schedule_model->getGameBaseInfo($gameId);
        $data = $this->game_record_model->getGamePointScoreById($gameId, $teamId);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=coach_progression_report.csv');
        $out = fopen('php://output', 'w');

        fputcsv($out, array('Date of Game', $base_info['game_date']));
        fputcsv($out, array('Opponent', $base_info['competition_name']));
        fputcsv($out, array('Loaction', $base_info['field_name']));

        if (sizeof($data)) {
            $home_team_score = 0;
            $away_team_score = 0;
            $this->load->model('game_finalize_score_model');
            $score = $this->game_finalize_score_model->getRowByGameID($gameId);
            if ($score) {
                $home_team_score = $score->home_score;
                $away_team_score = $score->away_score;
            } else {
                foreach ($data as $score) {
                    if ($base_info['home_team_id'] == $score['team_id']) {
                        $home_team_score += $score['scores'];
                    }
                    if ($base_info['away_team_id'] == $score['team_id']) {
                        $away_team_score += $score['scores'];
                    }
                }
            }
            fputcsv($out, array('Result/Score', ' ' . $home_team_score . " - " . $away_team_score . ' '));
            fputcsv($out, array(''));
            fputcsv($out, array('Item Type', 'Point', 'Score', 'Ratio'));
            foreach ($data as $row) {
                if ($base_info['home_team_id'] == $row['team_id']) {
                    $ratio = 0;
                    if ($row['item_id'] == '119' || $row['item_id'] == '122' || $row['item_id'] == '125') {
                        $attempt_id = $row['item_id'] * 1 - 1;
                        $attempt_cnt = 1;
                        foreach ($data as $r) {
                            if ($r['item_id'] == $attempt_id) {
                                $attempt_cnt = $r['cnt'];
                            }

                        }
                        $ratio = round($row['cnt'] / $attempt_cnt * 100, 2);
                    }
                    fputcsv($out, array($row['item_name'], ($row['pts'] ? $row['pts'] : ''), ($row['scores'] ? $row['scores'] : ''), ''));
                    if ($ratio) {
                        $item = $this->base_record_item_model->getRowById($row['item_id'] * 1 + 1);
                        fputcsv($out, array($item->item_name, '', '', $ratio . '%'));
                    }
                }
            }

            fputcsv($out, array(''));
            fputcsv($out, array('Player Stat'));
            fputcsv($out, array(''));
            $this->load->model('game_roster_model');
            $players = $this->game_roster_model->getGamePlayerInfo($teamId, $gameId);
            $header = array();
            $body = array();
            if ($players) {
                $this->load->model('base_record_item_model');
                $this->load->model('person_player_model');
                $header = array('#', 'Player Name');
                foreach ($players as $key => $player) {
                    $playerInfo = $this->person_player_model->getPlayerById($player->player_id);
                    $status = $this->game_record_model->playerStatistic($gameId, $teamId, $player->player_id);
                    $body[$key] = array(
                        $player->player_number, $playerInfo['first_name'] . ' ' . $playerInfo['last_name'],
                    );
                    foreach ($status as $item_key => $value) {
                        if ($key == 0) {
                            $itemRow = $this->base_record_item_model->getRowByName($item_key);
                            $header[] = $itemRow->short_name;
                        }
                        $body[$key][] = $value;
                    }
                }
            }
            if ($header && $body) {
                fputcsv($out, $header);
                foreach ($body as $data) {
                    fputcsv($out, $data);
                }
            }
        }
        fclose($out);
    }
}
